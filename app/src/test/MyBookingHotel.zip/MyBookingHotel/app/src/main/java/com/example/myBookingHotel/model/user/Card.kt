package com.example.myBookingHotel.model.user

import com.google.gson.annotations.SerializedName

data class Card(
    @SerializedName("card_id")
    var cardId: String?,
    @SerializedName("card_number")
    var cardNumber: String?,
    @SerializedName("name")
    var name: String?,
    @SerializedName("pin_code")
    var pinCode: String?,
    @SerializedName("bank_name")
    var bankName: String?,
    @SerializedName("total_money")
    var totalMoney: Long?
)