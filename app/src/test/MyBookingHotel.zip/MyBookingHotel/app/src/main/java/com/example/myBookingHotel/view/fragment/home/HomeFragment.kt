package com.example.myBookingHotel.view.fragment.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.myBookingHotel.databinding.FragmentHomeBinding
import com.example.myBookingHotel.view.fragment.BaseFragment
import com.example.myBookingHotel.viewmodel.utils.listener.ScrollCallback

class HomeFragment : BaseFragment() {

    private var binding: FragmentHomeBinding? = null
    private var scrollCallback: ScrollCallback? = null

    companion object {
        @JvmStatic
        fun newInstance(scrollCallback: ScrollCallback) =
            HomeFragment().apply {
                arguments = Bundle().apply {
                }
                setListener(scrollCallback)
            }
    }

    fun setListener(scrollCallback: ScrollCallback) {
        this.scrollCallback = scrollCallback
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        if (binding == null) {
            binding = FragmentHomeBinding.inflate(inflater, container, false)
        } else {
            (binding!!.root.parent as? ViewGroup)?.removeView(binding!!.root)
        }
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!hasInitializedRootView) {
            hasInitializedRootView = true

            initUI()
        }
    }

    private fun initUI() {

    }
}