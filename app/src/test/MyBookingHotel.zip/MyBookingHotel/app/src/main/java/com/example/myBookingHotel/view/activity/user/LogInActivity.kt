package com.example.myBookingHotel.view.activity.user

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Patterns
import android.view.View
import com.example.myBookingHotel.databinding.ActivityLogInBinding
import com.example.myBookingHotel.view.activity.BaseActivity
import com.example.myBookingHotel.view.activity.main.MainActivity
import com.example.myBookingHotel.viewmodel.utils.helper.GlobalHelper


class LogInActivity : BaseActivity() {

    private var binding: ActivityLogInBinding? = null
    private var isSettingFragment: Boolean? = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogInBinding.inflate(layoutInflater)
        isSettingFragment = intent.extras?.getBoolean("isSettingFragment", false)
        setContentView(binding!!.root)
        initUI()
        onClick()
    }

    private fun initUI() {
        isSettingFragment?.let {
            binding?.icBack?.visibility = if (it) View.VISIBLE else View.GONE
        }
        binding?.apply {
            tvLoginSuccess.visibility = View.GONE
            tvLoginFail.visibility = View.GONE
        }
    }

    private fun onClick() {
        binding?.let {
            it.tvRegister.setOnClickListener { _ ->
                startActivity(Intent(this, RegisterActivity::class.java))
            }
            it.btnLogIn.setOnClickListener { _ ->
                GlobalHelper().closeKeyboard(this@LogInActivity)
                if (checkValidate()) {
                    it.tvLoginSuccess.visibility = View.VISIBLE
                    it.tvLoginFail.visibility = View.GONE
                    Handler().postDelayed({
                        preferenceHelper.statusLogin = true
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    }, 200)
                } else {
                    it.tvLoginSuccess.visibility = View.GONE
                    it.tvLoginFail.visibility = View.VISIBLE
                }
            }
            it.icBack.setOnClickListener { _ ->
                finish()
            }
        }
    }

    private fun checkValidate(): Boolean {
        val email = binding!!.etEmail.text.toString().trim()
        val password = binding!!.etPassword.text.toString().trim()
        return Patterns.EMAIL_ADDRESS.matcher(email).matches() && password.length > 5
    }

}