package com.example.myBookingHotel.model.hotel

import com.google.gson.annotations.SerializedName

data class Hotel(
    @SerializedName("id_hotel")
    var hotelId: String,
    @SerializedName("hotel_name")
    var hotelName: String?,
    @SerializedName("location")
    var location: Location?,
    @SerializedName("star")
    var star: Int?,
    @SerializedName("vote")
    var vote: Int?,
    @SerializedName("vote_total")
    var voteTotal: Int?,
    @SerializedName("rooms")
    var listRoom: List<Room>?
)