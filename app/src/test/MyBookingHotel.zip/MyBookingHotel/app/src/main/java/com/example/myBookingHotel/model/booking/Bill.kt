package com.example.myBookingHotel.model.booking

import com.google.gson.annotations.SerializedName

data class Bill(
    @SerializedName("id_bill")
    var billId: String?,
    @SerializedName("id_user")
    var userId: String?,
    @SerializedName("id_hotel")
    var hotelId: String?,
    @SerializedName("id_room")
    var roomId: String?,
    @SerializedName("checkIn")
    var checkIn: String?,
    @SerializedName("checkOut")
    var checkOut: String?,
    @SerializedName("total_price")
    var totalPrice: Long?
)