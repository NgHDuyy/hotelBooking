package com.example.myBookingHotel.viewmodel.utils.helper

import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import com.example.myBookingHotel.R

class GlobalHelper {

    val preferenceNameApp = "com.example.myBookingHotel"

    val widthScreen = "widthScreen"
    val heightScreen = "heightScreen"
    val statusLogin = "statusLogin"
    val languageDevice = "language_device"


    fun slideView(view: View, currentHeight: Int, newHeight: Int, duration: Int) {
        val slideAnimator =
            ValueAnimator.ofInt(currentHeight, newHeight).setDuration(duration.toLong())

        /* We use an update listener which listens to each tick
         * and manually updates the height of the view  */slideAnimator.addUpdateListener { animation1: ValueAnimator ->
            view.layoutParams.height = (animation1.animatedValue as Int)
            view.requestLayout()
        }

        /*  We use an animationSet to play the animation  */
        val animationSet = AnimatorSet()
        animationSet.interpolator = AccelerateDecelerateInterpolator()
        animationSet.play(slideAnimator)
        animationSet.start()
    }

    fun closeKeyboard(activity: Activity) {
        val view = activity.currentFocus
        if (view != null) {
            val imm = activity.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }

    fun getLanguageApp(context: Context, languageCode: String?): String {
        when (languageCode) {
            "en" -> return context.resources.getString(R.string.english)
            "vi" -> return context.resources.getString(R.string.vietnam)
        }
        return context.resources.getString(R.string.vietnam)
    }
}