package com.example.myBookingHotel.viewmodel.utils.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory

class APIHelper(private val BASE_URL: String = "") {

    private var bookingApi: API? = null

    private val api: API
        get() {
            if (bookingApi == null) {
                bookingApi = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build().create(API::class.java)
            }
            return bookingApi!!
        }




    interface API {

    }
}