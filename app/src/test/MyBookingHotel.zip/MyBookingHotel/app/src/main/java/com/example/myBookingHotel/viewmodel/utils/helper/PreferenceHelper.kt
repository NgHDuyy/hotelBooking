package com.example.myBookingHotel.viewmodel.utils.helper

import android.content.Context
import com.example.myBookingHotel.R

class PreferenceHelper(private val context: Context, name: String = PREFERENCES_NAME) {
    private val sharedPreferences = context.getSharedPreferences(name, Context.MODE_PRIVATE)

    companion object {
        val globalHelper = GlobalHelper()
        val PREFERENCES_NAME = globalHelper.preferenceNameApp
    }


    var widthScreen: Int
        get() {
            return sharedPreferences.getInt(globalHelper.widthScreen, 0)
        }
        set(value) {
            sharedPreferences.edit().putInt(globalHelper.widthScreen, value).apply()
        }


    var heightScreen: Int
        get() {
            return sharedPreferences.getInt(globalHelper.heightScreen, 0)
        }
        set(value) {
            sharedPreferences.edit().putInt(globalHelper.heightScreen, value).apply()
        }

    var statusLogin: Boolean
        get() {return sharedPreferences.getBoolean(globalHelper.statusLogin, false)}
        set(value) {
            sharedPreferences.edit().putBoolean(globalHelper.statusLogin, value).apply()
        }

    var languageDevice: String
        get() {
            return sharedPreferences.getString(
                globalHelper.languageDevice, context.getString(R.string.txt_language)
            ) ?: context.getString(R.string.txt_language)
        }
        set(value) {
            sharedPreferences.edit().putString(globalHelper.languageDevice, value).apply()
        }
}