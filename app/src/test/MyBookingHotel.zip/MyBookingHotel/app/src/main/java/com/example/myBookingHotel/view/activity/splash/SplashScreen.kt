package com.example.myBookingHotel.view.activity.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.DisplayMetrics
import com.example.myBookingHotel.R
import com.example.myBookingHotel.view.activity.BaseActivity
import com.example.myBookingHotel.view.activity.main.MainActivity
import com.example.myBookingHotel.view.activity.user.LogInActivity

class SplashScreen : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        initUI()
    }

    private fun initUI() {
        checkDataDevice()
        checkLogin()
    }

    private fun checkDataDevice() {
        if (preferenceHelper.widthScreen == 0 || preferenceHelper.heightScreen == 0) {
            val displayMetrics = DisplayMetrics()
            windowManager?.defaultDisplay?.getMetrics(displayMetrics)
            val width = displayMetrics.widthPixels
            preferenceHelper.widthScreen = width

            val height = displayMetrics.heightPixels
            preferenceHelper.heightScreen = height
        }
    }

    private fun checkLogin() {
        Handler().postDelayed({
            if (preferenceHelper.statusLogin) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                startActivity(Intent(this, LogInActivity::class.java))
                finish()
            }
        }, 1000)
    }
}