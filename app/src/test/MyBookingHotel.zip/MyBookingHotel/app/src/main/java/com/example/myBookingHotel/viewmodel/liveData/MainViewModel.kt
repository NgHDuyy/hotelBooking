package com.example.myBookingHotel.viewmodel.liveData

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
}