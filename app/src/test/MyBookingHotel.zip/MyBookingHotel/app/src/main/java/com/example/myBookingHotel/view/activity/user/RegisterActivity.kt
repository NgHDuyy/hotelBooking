package com.example.myBookingHotel.view.activity.user

import android.os.Bundle
import android.os.Handler
import android.util.Patterns
import android.view.View
import com.example.myBookingHotel.databinding.ActivityRegisterLogInBinding
import com.example.myBookingHotel.view.activity.BaseActivity

class RegisterActivity : BaseActivity() {

    private var binding: ActivityRegisterLogInBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterLogInBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        initUI()
        onClick()
    }

    private fun initUI() {
        binding?.apply {
            tvInvalidateName.visibility = View.GONE
            tvInvalidatePhone.visibility = View.GONE
            tvInvalidateEmail.visibility = View.GONE
            tvInvalidatePassword.visibility = View.GONE
            tvInvalidateRePassword.visibility = View.GONE
            tvRegisterSuccess.visibility = View.GONE
            tvRegisterFail.visibility = View.GONE
        }
    }

    private fun onClick() {
        binding?.let {
            it.btnRegister.setOnClickListener { _ ->
                globalHelper.closeKeyboard(this@RegisterActivity)
                if (checkValidate()) {
                    it.apply {
                        tvInvalidateName.visibility = View.GONE
                        tvInvalidatePhone.visibility = View.GONE
                        tvInvalidateEmail.visibility = View.GONE
                        tvInvalidatePassword.visibility = View.GONE
                        tvInvalidateRePassword.visibility = View.GONE
                        tvRegisterSuccess.visibility = View.VISIBLE
                        tvRegisterFail.visibility = View.GONE
                    }
                    Handler().postDelayed({
                        finish()
                    }, 200)
                } else {
                    if (!checkValidateName()) {
                        binding!!.tvInvalidateName.visibility = View.VISIBLE
                    }
                    if (!checkValidatePhone()) {
                        binding!!.tvInvalidatePhone.visibility = View.VISIBLE
                    }
                    if (!checkValidateEmail()) {
                        binding!!.tvInvalidateEmail.visibility = View.VISIBLE
                    }
                    if (!checkValidatePassword()) {
                        binding!!.tvInvalidatePassword.visibility = View.VISIBLE
                    }
                    if (!checkValidateRePassword()) {
                        binding!!.tvInvalidateRePassword.visibility = View.VISIBLE
                    }
                }
            }
            it.icBack.setOnClickListener { finish() }
        }
    }

    private fun checkValidate(): Boolean {
        return checkValidateName() && checkValidatePhone() && checkValidateEmail() && checkValidatePassword() && checkValidateRePassword()
    }

    private fun checkValidateName(): Boolean {
        return binding!!.etName.text.toString().trim().isNotEmpty()
    }

    private fun checkValidatePhone(): Boolean {
        val phone = binding!!.etPhoneNumber.text.toString().trim()
        return Patterns.PHONE.matcher(phone).matches()
    }

    private fun checkValidateEmail(): Boolean {
        val email = binding!!.etEmail.text.toString().trim()
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun checkValidatePassword(): Boolean {
        return binding!!.etPassword.text.toString().trim().length > 5
    }

    private fun checkValidateRePassword(): Boolean {
        return binding!!.etConfirmPassword.text.toString()
            .trim() == binding!!.etPassword.text.toString().trim()
    }
}