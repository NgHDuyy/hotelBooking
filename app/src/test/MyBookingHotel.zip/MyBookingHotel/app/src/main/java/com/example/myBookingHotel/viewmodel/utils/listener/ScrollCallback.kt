package com.example.myBookingHotel.viewmodel.utils.listener

public interface ScrollCallback {
    fun execute(scrollDown: Boolean, tabScroll: Int)

}