package com.example.myBookingHotel.model.hotel

import com.google.gson.annotations.SerializedName

data class Room(
    @SerializedName("room_id")
    var idRoom: String?,
    @SerializedName("room_number")
    var roomNumber: Int?,  
    @SerializedName("number_bed")
    var numberBed: Int?,
    @SerializedName("maximum_people")
    var maximumPeople: Int?,
    @SerializedName("price_hour")
    var priceHour: Long?,
    @SerializedName("price_day")
    var priceDay: Long?,
    @SerializedName("discount")
    var discount: Int?,
    @SerializedName("description")
    var description: String?,
    @SerializedName("images")
    var listURL: List<String>?,
    @SerializedName("isBooked")
    var isBooked: Boolean
)